import { setupGlobal } from '@technote-space/github-action-test-helper';

setupGlobal();
